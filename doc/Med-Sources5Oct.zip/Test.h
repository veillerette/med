#ifndef __HEAD_TEST__
#define __HEAD_TEST__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "Step.h"
#include "Staff.h"
#include "System.h"


extern int Test_Main(void);


#endif
